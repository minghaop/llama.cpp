// Copyright 2024 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef THIRD_PARTY_ODML_LITERT_LITERT_CC_INTERNAL_LITERT_CONSTS_H_
#define THIRD_PARTY_ODML_LITERT_LITERT_CC_INTERNAL_LITERT_CONSTS_H_

#include <cstddef>

/// @file
/// @brief Defines constants used for optimizing `absl::InlinedVector` sizes.

namespace litert {

/// @brief These constants are used to properly size `absl::InlinedVector`
/// instances throughout the LiteRT code. Their values are optimization hints
/// and do not need to be exact.
static constexpr size_t kExpectedMaxTensorRank = 6;
static constexpr size_t kExpectedMaxNumOfTensorUses = 8;
static constexpr size_t kExpectedMaxNumOfOpInputs = 4;
static constexpr size_t kExpectedMaxNumOfOpOutputs = 8;
static constexpr size_t kExpectedMaxNumOfSubgraphInputs = 4;
static constexpr size_t kExpectedMaxNumOfSubgraphOutputs = 4;

/// @brief Default signature key. This is the key that is used if models don't
/// define any signatures.
static constexpr char kDefaultSignatureKey[] = "<placeholder signature>";
}  // namespace litert

#endif  // THIRD_PARTY_ODML_LITERT_LITERT_CC_INTERNAL_LITERT_CONSTS_H_
