// Copyright 2024 Google LLC.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ODML_LITERT_LITERT_CC_LITERT_HANDLE_H_
#define ODML_LITERT_LITERT_CC_LITERT_HANDLE_H_

#include <functional>
#include <memory>
#include <type_traits>

/// @file
/// @brief Defines handle classes for managing the lifetime of opaque C API
/// handles.

namespace litert {

enum class OwnHandle { kNo, kYes };

namespace internal {

template <typename H>
inline void DummyDeleter(H) {}

/// @brief A smart pointer-like class for managing the lifetime of opaque
/// handles from the C API.
///
/// This class wraps a `std::unique_ptr` to provide automatic resource
/// management for C-style handles. It supports both owning and non-owning
/// semantics.
/// @tparam H The handle type.
/// TODO(b/477360280): Rename this class to Handle once the migration is done.
template <typename H>
class BaseHandle {
 public:
  using Deleter = std::function<void(H)>;

  BaseHandle() = default;

  /// @brief Creates a new `BaseHandle`.
  /// @param handle The handle to manage.
  /// @param deleter The deleter for the handle.
  /// @param own Whether this object owns the handle.
  BaseHandle(H handle, Deleter deleter, OwnHandle own) noexcept
      : ptr_(handle,
             own == OwnHandle::kYes ? std::move(deleter) : DummyDeleter<H>),
        owns_(own) {}

  /// @brief Returns `true` if the underlying LiteRT handle is valid.
  explicit operator bool() const noexcept { return static_cast<bool>(ptr_); }

  bool operator==(const BaseHandle& other) const noexcept {
    return Get() == other.Get();
  }
  bool operator!=(const BaseHandle& other) const noexcept {
    return Get() != other.Get();
  }

  /// @brief Returns the underlying LiteRT handle.
  H Get() const noexcept { return ptr_.get(); }

  /// @brief Returns the deleter for the handle.
  Deleter GetDeleter() const noexcept { return ptr_.get_deleter(); }

  /// @brief Releases ownership of the handle.
  ///
  /// After this call, `Get()` returns a null handle.
  H Release() noexcept {
    owns_ = OwnHandle::kNo;  // Releasing means we no longer own.
    return ptr_.release();
  }

  /// @brief Returns `true` if the underlying handle is managed by this object.
  bool IsOwned() const noexcept { return owns_ == OwnHandle::kYes; }

 private:
  std::unique_ptr<std::remove_pointer_t<H>, std::function<void(H)>> ptr_ = {
      nullptr, DummyDeleter<H>};
  OwnHandle owns_ = OwnHandle::kNo;
};

/// @brief A specialization of `BaseHandle` for owned handles.
///
/// @tparam H The handle type.
/// @tparam deleter A function pointer to the deleter for the handle.
///
/// @deprecated Use `BaseHandle` instead.
template <typename H, void (*deleter)(H)>
class [[deprecated("Use BaseHandle instead.")]] Handle : public BaseHandle<H> {
 public:
  Handle() = default;

  explicit Handle(H handle, OwnHandle own) noexcept
      : BaseHandle<H>(handle, deleter, own) {}
};

/// @brief A specialization of `Handle` for non-owned handles.
///
/// This class ensures that the managed opaque handle is not destroyed when the
/// `NonOwnedHandle` object goes out of scope.
/// @tparam H The handle type.
template <typename H>
class NonOwnedHandle : public BaseHandle<H> {
 public:
  explicit NonOwnedHandle(H handle) noexcept
      : BaseHandle<H>(handle, DummyDeleter<H>, OwnHandle::kNo) {}
};

}  // namespace internal
}  // namespace litert

#endif  // ODML_LITERT_LITERT_CC_LITERT_HANDLE_H_
